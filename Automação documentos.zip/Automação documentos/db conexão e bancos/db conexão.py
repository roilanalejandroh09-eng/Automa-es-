# db/database.py
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import datetime

# Configuração do banco (exemplo com PostgreSQL)
DATABASE_URL = "postgresql+psycopg2://usuario:senha@localhost:5432/automacao_docs"

engine = create_engine(DATABASE_URL, echo=True)
SessionLocal = sessionmaker(bind=engine)

Base = declarative_base()

class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String(255))
    cpf = Column(String(20))
    data = Column(String(20))
    doc_type = Column(String(50))
    file_path = Column(String(255))
    raw_text = Column(Text)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

def init_db():
    """Cria as tabelas no banco de dados"""
    Base.metadata.create_all(bind=engine)

def save_document(data, file_path, doc_type, raw_text):
    """
    Salva os metadados do documento no banco.
    """
    session = SessionLocal()
    try:
        doc = Document(
            nome=data.get("nome"),
            cpf=data.get("cpf"),
            data=data.get("data"),
            doc_type=doc_type,
            file_path=file_path,
            raw_text=raw_text
        )
        session.add(doc)
        session.commit()
        session.refresh(doc)
        return doc
    except Exception as e:
        session.rollback()
        print(f"Erro ao salvar documento: {e}")
    finally:
        session.close()
