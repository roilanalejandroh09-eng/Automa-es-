#ocr_module 
import pytesseract
from PIL import Image
import cv2
import re

def prepocess_image(image_path):
    """
    -Pre-processa a imagem para melhorar a precisão do OCR.
    -Aplcica limiarização, remoção de ruido e ajuste de contraste.
    -Retorna a imagem pré-processada.
    """
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray,150,255,cv2.THRESH_BINARY)
    return thresh

    def extract_text(image_path):
    """
    -Extrai texto de uma imagem usando OCR
    -Retorna o texto extraído.
    """
    processed_img = prepocess_image(image_path)
    text = pytesseract.image_to_string(processed_img, lang='por')
    text = re.sub(r'\s+', '', text).strip()
    return text

    def extract_fields(text,patterns):
    """
    -Extrao campos especificos do texto usando expressões regulares.
    Exemplo: nome, cpf, rg, data de nascimento.
    """
    extracted_data = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, text)
        if match:
            extracted_data[key] = match.group(1)
            return extracted_data
            