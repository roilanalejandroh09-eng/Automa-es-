# main.py
import sys
from workflow.workflow import process_document
from db.database import init_db
from utils.helpers import log_info, log_error

def main():
    # Inicializa o banco de dados
    init_db()
    log_info("Banco de dados inicializado.")

    # Verifica se foi passado um arquivo como argumento
    if len(sys.argv) < 2:
        log_error("Nenhum arquivo de imagem informado.")
        print("Uso: python main.py caminho/para/imagem.png [tipo_documento]")
        return

    image_path = sys.argv[1]
    doc_type = sys.argv[2] if len(sys.argv) > 2 else "contract"

    # Processa o documento
    output = process_document(image_path, doc_type)

    if output:
        print(f"✅ Documento gerado com sucesso: {output}")
    else:
        print("❌ Falha ao processar o documento.")

if __name__ == "__main__":
    main()
