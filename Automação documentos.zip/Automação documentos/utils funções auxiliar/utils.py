#utils/helpers
import logging
import re

#Configuração  basica de logging
logging.basicConfig(
    filename="logs/automação_docs.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
def log_info(message):
    """Registra mensagens informativas no log."""
    logging.info(message)
    print(f"[INFO] {message}")

    def log_error(message):
        """Registra mensagens de erro no log."""
        logging.error(message)
        print(f"[ERROR] {message}")

        def validate_cpf(cpf):
            """
            Valida o formato do CPF.
            Retorna true se valido, caso contrário, false.
            """
            pattern = r"^\d{3}\.\d{3}\.\d{3}-\d{2}$"
            return bool(re.match(pattern, cpf))
        
        def clean_text(text):
            """Remove espaços extras e carateres indesejados do texto."""
            return re.sub(r'^\s+|\s+$', '', text)