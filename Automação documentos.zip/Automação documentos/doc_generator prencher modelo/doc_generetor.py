# doc_generator/generator.py
from docxtpl import DocxTemplate 

def fill_template(template_path, output_path, context):
    """
    Preenche um modelo .docx com os dados fornecidos e salva o resultado.
    """
    doc = DocxTemplate(template_path)
    doc.render(context)
    doc.save(output_path)
    return output_path

def generate_contract(template_path, output_path, context):
    """
    Exemplo de função específica para gerar um contrato usando um modelo .docx.
    """
    return fill_template(template_path, output_path, context)

def generate_order(template_path="templates/ordem_servico.docx", 
                   output_path="output/ordem_servico.docx", 
                   context=None):
    """
    Exemplo de função específica para gerar ordens de serviço.
    """
    return fill_template(template_path, output_path, context)
