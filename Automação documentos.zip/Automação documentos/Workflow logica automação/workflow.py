# workflow/workflow.py
import os
from ocr_module.ocr import extract_text, extract_fields
from doc_generator.generator import generate_contract, generate_order
from db.database import save_document
from utils.helpers import log_info, log_error

def process_document(image_path, doc_type="contract"):
    """
    Fluxo principal:
    1. Extrai texto da imagem (OCR)
    2. Identifica campos relevantes (regex)
    3. Gera documento preenchido (.docx)
    4. Salva no banco de dados
    """

    try:
        log_info(f"Processando documento: {image_path}")
        text = extract_text(image_path)

        patterns = {
            "nome": r"Nome:\s*([A-Za-zÀ-ÿ\s]+)",
            "cpf": r"CPF:\s*([\d.-]+)",
            "data": r"Data:\s*([\d/]+)"
        }
        data = extract_fields(text, patterns)

        os.makedirs("output", exist_ok=True)

        if doc_type == "contract":
            output_path = generate_contract(
                template_path="templates/contrato.docx",
                output_path=f"output/contrato_{data.get('nome','sem_nome')}.docx",
                context=data
            )
        elif doc_type == "order":
            output_path = generate_order(
                template_path="templates/ordem_servico.docx",
                output_path=f"output/ordem_{data.get('nome','sem_nome')}.docx",
                context=data
            )
        else:
            raise ValueError("Tipo de documento não suportado.")

        save_document(data=data, file_path=output_path, doc_type=doc_type, raw_text=text)

        log_info(f"Documento gerado e salvo: {output_path}")
        return output_path

    except Exception as e:
        log_error(f"Erro no processamento: {e}")
        return None
